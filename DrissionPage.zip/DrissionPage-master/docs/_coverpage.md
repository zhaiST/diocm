# DrissionPage

DrissionPage 是一个 Web 自动化框架。  
以页面为单位整合浏览器和 requests，封装了常用操作。  
极大地简化了代码，易于使用，并可实现两种模式的无缝切换。  
可兼顾浏览器的易用性和 requests 的高性能。

如果本库对你有所帮助，请给予支持！持续维护中。

![Gitee-Stars](https://gitee.com/g1879/DrissionPage/badge/star.svg?theme=dark)
![Forks](https://gitee.com/g1879/DrissionPage/badge/fork.svg?theme=dark)

[Gitee](https://gitee.com/g1879/DrissionPage)
[开始阅读](README.md)