#!/usr/bin/python3
# --coding:utf-8--
# @File: startApp
# @Author:leic
# @Time: 2020年05月07日

import json
import logging
import os
import shutil
import zipfile

import SimpleITK as sitk
import requests
import numpy as np
from pydicom.filereader import dcmread
import time, random
import shutil
from concurrent.futures import ThreadPoolExecutor
executor = ThreadPoolExecutor()

status = "idle"

header_json = {
    "version": "2.0",
    "info": {
        "name": "GU JIAN QIANG",
    },
    "volume": {
        "parts": [
            {
                "type": "nrrd",
                "path": "GU JIAN QIANG_CSY-ProstateNEW(50Phase)_20190713104551_600.nrrd"
            }
        ]
    }
}


def resize_image_itk(itkimage, newSpacing, resamplemethod=sitk.sitkBSpline):
    """
    image resize withe sitk resampleImageFilter
    :param itkimage:
    :param newSpacing:such as [1,1,1]
    :param resamplemethod:
    :return:
    """
    newSpacing = np.array(newSpacing, float)
    originSpcaing = itkimage.GetSpacing()
    resampler = sitk.ResampleImageFilter()
    originSize = itkimage.GetSize()
    factor = newSpacing / originSpcaing
    newSize = originSize / factor
    newSize = newSize.astype(np.int)
    resampler.SetReferenceImage(itkimage)  # 将输出的大小、原点、间距和方向设置为itkimage
    resampler.SetOutputSpacing(newSpacing.tolist())  # 设置输出图像间距
    resampler.SetSize(newSize.tolist())  # 设置输出图像大小
    resampler.SetTransform(sitk.Transform(3, sitk.sitkIdentity))
    resampler.SetInterpolator(resamplemethod)
    itkimgResampled = resampler.Execute(itkimage)
    return itkimgResampled

def processOutput(fileJson):
    global status
    status = "busy"
    payload = {"uId": fileJson["uId"]}
    outputDir = fileJson["outputDir"]
    if not os.path.exists(outputDir):
        os.mkdir(outputDir)
    #pacsPath = os.path.join(outputDir, fileJson["exportChannel"][0]["exportDir"])
    #if not os.path.exists(pacsPath):
    #    os.mkdir(pacsPath)
    dataJson = fileJson['requestInfo']
    responseUrl = fileJson['responseUrl']
    return outputDir, dataJson, responseUrl, payload


def convertpath(series_file_names, outputdir):
    file_name = dump_dcm_info(series_file_names[0], outputdir)
    # 转换nrrd文件
    dcm_dir=os.path.join(outputdir, "tmp")
    os.mkdir(dcm_dir)
    for tmp_file_name in series_file_names:
        shutil.copy(tmp_file_name,dcm_dir)
    series_reader = sitk.ImageSeriesReader()
    series_reader.MetaDataDictionaryArrayUpdateOn()
    series_reader.LoadPrivateTagsOn()
    series_IDs = sitk.ImageSeriesReader.GetGDCMSeriesIDs(dcm_dir)
    dicom_names = series_reader.GetGDCMSeriesFileNames(dcm_dir, series_IDs[0])
    series_reader.SetFileNames(dicom_names)
    images = series_reader.Execute()
    r_sample_image = resize_image_itk(images, [1.5, 1.5, 2])
    input_file = file_name + ".nrrd"
    sitk.WriteImage(r_sample_image, input_file)
    shutil.rmtree(dcm_dir)
    # 将nrrd文件进行压缩 hobjs
    output_file = file_name + ".hobjs"
    header_index = os.path.join(outputdir, ".HOBJSINDEX")
    with open(header_index, "w") as fp:
        json.dump(header_json, fp)
    with zipfile.ZipFile(output_file, "w") as zip:
        zip.write(input_file, os.path.split(input_file)[-1], compress_type=zipfile.ZIP_DEFLATED)
        zip.write(header_index, os.path.split(header_index)[-1], compress_type=zipfile.ZIP_DEFLATED)
    # delete nrrd file
    os.remove(file_name + ".nrrd")
    os.remove(header_index)


def dump_dcm_info(dcm_file, outputdir):
    '''
     保存dcm原始信息
    :param dcm_file:
    :param outputdir:
    :return:
    '''
    with dcmread(dcm_file) as ds:
        for name in ds.dir("Patient"):
            header_json["info"][name] = str(ds[name].value)
        for name in ds.dir("Study"):
            header_json["info"][name] = str(ds[name].value)
        for name in ds.dir("Series"):
            header_json["info"][name] = str(ds[name].value)
    file_name_array = []
    if hasattr(ds, "PatientName"):
        file_name_array.append(str(ds.PatientName))
    if hasattr(ds, "ProtocolName"):
        file_name_array.append(str(ds.ProtocolName).replace("/",""))
    if hasattr(ds, "StudyDate") and hasattr(ds, "StudyTime"):
        file_name_array.append(str(ds.StudyDate) + str(ds.StudyTime))
    if hasattr(ds, "SeriesNumber"):
        file_name_array.append(str(ds.SeriesNumber))
    file_name = os.path.join(outputdir, "_".join(file_name_array))
    file_name = file_name.replace("(","").replace(")","")
    file_name = file_name.replace(" ","")
    header_json["info"]["name"] = str(ds.PatientName)
    header_json["volume"]["parts"][0]["path"] = os.path.basename(file_name + ".nrrd")
    logging.info("seriesInstanceUID:{} to nrrd file and file name is {}".format(ds.SeriesInstanceUID, file_name))
    return file_name

def Processing_data(id, outputdir):
    logging.info("Processing Images...")
    time.sleep(120 + random.randrange(20, 101, 10))
    if id == "ZS20065438":
        shutil.copyfile("/usr/gaorong/filebrowser-data/data/OD688508553526247424/WEN^YUSHUANG_results.hobjs", os.path.join(outputdir,"WEN^YUSHUANG_results.hobjs"))
    elif id == "00351376":
        shutil.copyfile("/usr/gaorong/filebrowser-data/data/OD688508553526247424/LiuAnSheng_results.hobjs", os.path.join(outputdir,"LiuAnSheng_results.hobjs"))
    elif id == "101198977":
        shutil.copyfile("/usr/gaorong/filebrowser-data/data/OD688508553526247424/HuYueHong_results.hobjs", os.path.join(outputdir,"HuYueHong_results.hobjs"))
    elif id == "5092454":
        shutil.copyfile("/usr/gaorong/filebrowser-data/data/OD688508553526247424/YuFengChun_Results.hobjs", os.path.join(outputdir,"YuFengChun_Results.hobjs"))
    elif id == "0000225048":
        shutil.copyfile("/usr/gaorong/filebrowser-data/data/OD688508553526247424/LiHaiLing_Results.hobjs", os.path.join(outputdir,"LiHaiLing_Results.hobjs"))
    else:
        shutil.copyfile("/usr/gaorong/filebrowser-data/data/OD688508553526247424/test_results.hobjs", os.path.join(outputdir,"test_results.hobjs"))
    logging.info("Done...")

def readrecursive(dataJson, outputdir):
    for i in range(len(dataJson)):
        if  dataJson[i]["id"] == "ZS20065438":
            Processing_data(dataJson[i]["id"], outputdir)
            break
        elif dataJson[i]["id"] == "101198977":
            Processing_data(dataJson[i]["id"], outputdir)
            break
        elif dataJson[i]["id"] == "00351376":
            Processing_data(dataJson[i]["id"], outputdir)
            break
        elif dataJson[i]["id"] == "0000988219":
            Processing_data(dataJson[i]["id"], outputdir)
            break
        elif dataJson[i]["id"] == "5092454":
            Processing_data(dataJson[i]["id"], outputdir)
            break
        elif dataJson[i]["id"] == "0000225048":
            Processing_data(dataJson[i]["id"], outputdir)
            break
        elif "nodeList" in dataJson[i]:
            convertpath(dataJson[i]["nodeList"], outputdir)
        else:
            readrecursive(dataJson[i]["childrenList"], outputdir)


def InferencePre(outputDir, dataJson, responseUrl, payload):
    try:
        readrecursive(dataJson, outputDir)
        resp_status = "success"
        logging.info("模型处理完成")
        payload["status"] = resp_status
        response = requests.post(responseUrl, data=payload)
        logging.info("中间件返回:{}".format(response.text))
    finally:
        global status
        status = "idle"
    print("done")


def init():
    pass


def infer(json_data):
    global status
    if status == "idle":
        outputDir, dataJson, responseUrl, payload = processOutput(json_data)
        InferencePre(outputDir,dataJson,responseUrl,payload)




def model_status():
    return status


#hello world